import re
import time
#python -m spacy download en_core_web_sm
#python -m spacy download en_core_web_md
#python -m spacy download en_core_web_lg
# import warning
# warnings.filterwarnings("ignore")

category = ['Case Report', 'Diagnosis', 'Epidemic Forecasting', 'General Info', 'Mechanism', 'Prevention', 'Transmission', 'Treatment', 'nan']
#prevention
abstract_text_1 ="OBJECTIVE: To prevent and control public health emergencies, we set up a prescreening and triage workflow and analyzed the effects on coronavirus disease 2019 (COVID-19). METHODS: In accordance with the requirements of the level 1 emergency response of public health emergencies in Shaanxi Province, China, a triage process for COVID-19 was established to guide patients through a 4-level triage process during their hospital visits. The diagnosis of COVID-19 was based on positive COVID-19 nucleic acid testing according to the unified triage standards of the Guidelines for the Diagnosis and Treatment of Novel Coronavirus Pneumonia (Trial version 4),4 issued by the National Health Commission of the People's Republic of China. RESULTS: The screened rate of suspected COVID-19 was 1.63% (4 of 246) in the general fever outpatient clinic and 8.28% (13 of 157) in the COVID-19 outpatient clinic, and they showed a significant difference (P = .00). CONCLUSIONS: The triage procedure effectively screened the patients and identified the high-risk population."
#prevention
abstract_text_2 = "The inhalation route has a substantial influence on the fate of inhaled particles. An outbreak of infectious diseases such as COVID-19, influenza or tuberculosis depends on the site of deposition of the inhaled pathogens. But the knowledge of respiratory deposition is important also for occupational safety or targeted delivery of inhaled pharmaceuticals. Simulations utilizing computational fluid dynamics are becoming available to a wide spectrum of users and they can undoubtedly bring detailed predictions of regional deposition of particles. However, if those simulations are to be trusted, they must be validated by experimental data. This article presents simulations and experiments performed on a geometry of airways which is available to other users and thus those results can be used for intercomparison between different research groups. In particular, three hypotheses were tested. First: Oral breathing and combined breathing are equivalent in terms of particle deposition in TB airways, as the pressure resistance of the nasal cavity is so high that the inhaled aerosol flows mostly through the oral cavity in both cases. Second: The influence of the inhalation route (nasal, oral or combined) on the regional distribution of the deposited particles downstream of the trachea is negligible. Third: Simulations can accurately and credibly predict deposition hotspots. The maximum spatial resolution of predicted deposition achievable by current methods was searched for. The simulations were performed using large-eddy simulation, the flow measurements were done by laser Doppler anemometry and the deposition has been measured by positron emission tomography in a realistic replica of human airways. Limitations and sources of uncertainties of the experimental methods were identified. The results confirmed that the high-pressure resistance of the nasal cavity leads to practically identical velocity profiles, even above the glottis for the mouth, and combined mouth and nose breathing. The distribution of deposited particles downstream of the trachea was not influenced by the inhalation route. The carina of the first bifurcation was not among the main deposition hotspots regardless of the inhalation route or flow rate. On the other hand, the deposition hotspots were identified by both CFD and experiments in the second bifurcation in both lungs, and to a lesser extent also in both the third bifurcations in the left lung."
#prevention and transmission
abstract_text_3 = "There is no specific treatment for SARS-CoV-2, and all infection control strategies are based on breaking the transmission chain of virus. The high transmission rate of SARS-CoV-2 has raised many questions about the possible routes of infection transmission. Due to uncertainty of the main transmission routes, the infection control policies faced with more challenges. The possible main route of transmission is thought to be the close contact and respiratory droplets. Therefore, it is necessary to maintain physical distance and using the face mask. Another routes of transmission are through contaminated surfaces as well as airborne, fecal-oral transmission."
#diagnosis
abstract_text_4 = "Ultrasound is the most disruptive innovation in intensive care life, above all in this time, with a high diagnostic value when applied appropriately. In recent years, point-of-care lung ultrasound has gained significant popularity as a diagnostic tool in the acutely dyspnoeic patients. In the era of Sars-CoV-2 outbreak, lung ultrasound seems to be strongly adapting to the follow-up for lung involvement of patients with ascertaining infections, till to be used, in our opinion emblematically, as a screening test in suspected patients at the emergency triage or at home medical visit. In this brief review, we discuss the lung ultrasound dichotomy, certainties and uncertainties, describing its potential role in validated clinical contexts, as a clinical-dependent exam, its limits and pitfalls in a generic and off-label clinical context, as a virtual anatomical-dependent exam, and its effects on the clinical management of patients with COVID-19."





# def count_term_in_doc(term,doc):
# 	pattern = '[\s,.-]'+term+'[\s,.-]'
# 	text = doc
# 	return len([*re.finditer(pattern, text)])


dic_str = []
for cat in category:
	name = cat.replace(' ','_') + ".out_term_list"
	file = open(name)
	res = ' '.join(file.readlines())
	dic_str.append(res)

from sklearn.feature_extraction.text import TfidfVectorizer

def get_dic_rel(abstract):
	temp = []
	for i in range(len(dic_str)):
		corpus = [dic_str[i],abstract]                                                                                                                                                                                                 
		vect = TfidfVectorizer(min_df=1, stop_words="english")                                                                                                                                                                                                   
		tfidf = vect.fit_transform(corpus)                                                                                                                                                                                                                       
		pairwise_similarity = tfidf * tfidf.T 
		temp.append(pairwise_similarity.toarray()[0][1])
	return temp

start_time = time.time()
print(get_dic_rel(abstract_text_1))
print("--- %s seconds ---" % (time.time() - start_time))


############################################################################
# import spacy
# nlp = spacy.load("en_core_web_lg")


# start_time = time.time()
# print("start training model for dic")
# dic_nlp = []
# for i in range(len(dic_str)):
# 	print("dic ", i, "done!")
# 	dic_nlp.append(nlp(dic_str[i]))
# print("train dictionary --- %s seconds ---" % (time.time() - start_time))

# def get_dic_rel(abstract):
# 	doc1 = nlp(abstract)
# 	return [model.similarity(doc1) for model in dic_nlp]

# print(get_dic_rel(abstract_text_1))

# start_time = time.time()
# doc1 = nlp(abstract_text_1)
# print([model.similarity(doc1) for model in dic_nlp])
# print("doc1 --- %s seconds ---" % (time.time() - start_time))

# start_time = time.time()
# doc2 = nlp(abstract_text_2)
# print([model.similarity(doc2) for model in dic_nlp])
# print("doc2 --- %s seconds ---" % (time.time() - start_time))

# start_time = time.time()
# doc3 = nlp(abstract_text_3)
# print([model.similarity(doc3) for model in dic_nlp])
# print("doc3 --- %s seconds ---" % (time.time() - start_time))

# start_time = time.time()
# doc4 = nlp(abstract_text_4)
# print([model.similarity(doc4) for model in dic_nlp])
# print("doc4 --- %s seconds ---" % (time.time() - start_time))
############################################################################




