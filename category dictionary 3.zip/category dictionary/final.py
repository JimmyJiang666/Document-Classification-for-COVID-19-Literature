import pandas as pd
import numpy as np
import nltk
from nltk.stem import WordNetLemmatizer,PorterStemmer
from nltk.corpus import stopwords
import re
import time

common_words = ["pandemic", "patient", "coronavirus", "disease", "case", "outbreak", "novel",\
                "pneumonia", "COVID-19", "Sars-CoV-2", "SARS-CoV-2", "covid-19", "Covid-19"]

common_word_dictionary = {}

category = ['Case Report', 'Diagnosis', 'Epidemic Forecasting', 'General Info', 'Mechanism', 'Prevention', 'Transmission', 'Treatment', 'nan']

for word in common_words:
    common_word_dictionary[word] = 1


train_set = pd.read_csv('train.csv')
test_set = pd.read_csv('test.csv')
from sklearn import preprocessing
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
enc = OneHotEncoder(handle_unknown='ignore')
le = preprocessing.LabelEncoder()

# X_train = [str(x) for x in train_set['title']]
# Y_train = [str(x).split(';') for x in train_set['label']]
limiter = len(test_set['label'])
train_categories = [str(x).split(';') for x in train_set['label']]
test_categories = [str(x).split(';') for x in test_set['label']][:limiter]



# trainDf = pd.DataFrame(train_set, columns=["abstract", "label"])
# testDf = pd.DataFrame(test_set, columns=["abstract", "label"])
trainDf = pd.DataFrame(train_set, columns=["abstract", "label"])
testDf = pd.DataFrame(test_set, columns=["abstract", "label"])[:limiter]


# print(trainDf.head)




wordnet_lemmatizer = WordNetLemmatizer()
stemmer = PorterStemmer()
stopwords = set(stopwords.words('english'))

def tokenize_lemma_stopwords(text):
    text = str(text).replace("\n", " ")
    # split string into words (tokens)
    tokens = nltk.tokenize.word_tokenize(text.lower())
    # keep strings with only alphabets
    tokens = [t for t in tokens if t.isalpha()]
    # put words into base form
    tokens = [wordnet_lemmatizer.lemmatize(t) for t in tokens]
    tokens = [stemmer.stem(t) for t in tokens]
    # remove short words, they're probably not useful
    tokens = [t for t in tokens if len(t) > 2]
    tokens = [t for t in tokens if t not in stopwords] # remove stopwords
    # tokens = [t for t in tokens if t not in common_word_dictionary]
    cleanedText = " ".join(tokens)
    return cleanedText

def dataCleaning(df):
    data = df.copy()
    # data["abstract"] = data["abstract"].apply(tokenize_lemma_stopwords)
    data["abstract"] = data["abstract"].apply(tokenize_lemma_stopwords)
    return data
cleanedTrainData = dataCleaning(trainDf)
cleanedTestData = dataCleaning(testDf)

# print(cleanedTrainData)





from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn import metrics

vectorizer = TfidfVectorizer()
vectorised_train_documents = vectorizer.fit_transform(cleanedTrainData["abstract"])
vectorised_test_documents = vectorizer.transform(cleanedTestData["abstract"])
# vectorised_train_documents = vectorizer.fit_transform(cleanedTrainData["abstract"])
# vectorised_test_documents = vectorizer.transform(cleanedTestData["abstract"])

# from yellowbrick.text import FreqDistVisualizer
# features = vectorizer.get_feature_names()
# visualizer = FreqDistVisualizer(features=features, orient='v')
# visualizer.fit(vectorised_train_documents)
# visualizer.show()

from sklearn.preprocessing import MultiLabelBinarizer

mlb = MultiLabelBinarizer()
train_labels = mlb.fit_transform(train_categories)
test_labels = mlb.transform(test_categories)

print(mlb.classes_)

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, hamming_loss

ModelsPerformance = {}

# def metricsReport(modelName, test_labels, predictions):
#     macro_f1 = f1_score(test_labels, predictions, average='macro')
#
#     micro_f1 = f1_score(test_labels, predictions, average='micro')
#
#     hamLoss = hamming_loss(test_labels, predictions)
#     ModelsPerformance[modelName] = micro_f1

def metricsReport(modelName, test_labels, predictions):
    accuracy = accuracy_score(test_labels, predictions)

    macro_precision = precision_score(test_labels, predictions, average='macro')
    macro_recall = recall_score(test_labels, predictions, average='macro')
    macro_f1 = f1_score(test_labels, predictions, average='macro')

    micro_precision = precision_score(test_labels, predictions, average='micro')
    micro_recall = recall_score(test_labels, predictions, average='micro')
    micro_f1 = f1_score(test_labels, predictions, average='micro')
    hamLoss = hamming_loss(test_labels, predictions)
    print("------" + modelName + " Model Metrics-----")
    print("Accuracy: {:.4f}\nHamming Loss: {:.4f}\nPrecision:\n  - Macro: {:.4f}\n  - Micro: {:.4f}\nRecall:\n  - Macro: {:.4f}\n  - Micro: {:.4f}\nF1-measure:\n  - Macro: {:.4f}\n  - Micro: {:.4f}"\
          .format(accuracy, hamLoss, macro_precision, micro_precision, macro_recall, micro_recall, macro_f1, micro_f1))
    ModelsPerformance[modelName] = micro_f1

# ------------- KNN ---------------

# from sklearn.neighbors import KNeighborsClassifier
#
# knnClf = KNeighborsClassifier()
#
# knnClf.fit(vectorised_train_documents, train_labels)
# knnPredictions = knnClf.predict(vectorised_test_documents)
# metricsReport("knn", test_labels, knnPredictions)


# ------------- Decision Tree ---------------


# from sklearn.tree import DecisionTreeClassifier
#
# dtClassifier = DecisionTreeClassifier()
# dtClassifier.fit(vectorised_train_documents, train_labels)
# dtPreds = dtClassifier.predict(vectorised_test_documents)
# metricsReport("Decision Tree", test_labels, dtPreds)

# # ------------- Random Forest ---------------

# from sklearn.ensemble import RandomForestClassifier
# rfClassifier = RandomForestClassifier(n_jobs=-1)
# rfClassifier.fit(vectorised_train_documents, train_labels)
# rfPreds = rfClassifier.predict(vectorised_test_documents)
# metricsReport("Random Forest", test_labels, rfPreds)

# # ------------- Bagging ---------------

# from sklearn.ensemble import BaggingClassifier
# from sklearn.multiclass import OneVsRestClassifier
#
# bagClassifier = OneVsRestClassifier(BaggingClassifier(n_jobs=-1))
# bagClassifier.fit(vectorised_train_documents, train_labels)
# bagPreds = bagClassifier.predict(vectorised_test_documents)
# metricsReport("Bagging", test_labels, bagPreds)

# # ------------- Boosting ---------------


# from sklearn.ensemble import GradientBoostingClassifier
# from sklearn.multiclass import OneVsRestClassifier
#
# boostClassifier = OneVsRestClassifier(GradientBoostingClassifier())
# boostClassifier.fit(vectorised_train_documents, train_labels)
# boostPreds = boostClassifier.predict(vectorised_test_documents)
# metricsReport("Boosting", test_labels, boostPreds)

# # ------------- Naive Bayes ---------------

# from sklearn.naive_bayes import MultinomialNB
# from sklearn.multiclass import OneVsRestClassifier
#
# nbClassifier = OneVsRestClassifier(MultinomialNB())
# nbClassifier.fit(vectorised_train_documents, train_labels)
#
# nbPreds = nbClassifier.predict(vectorised_test_documents)
# metricsReport("Multinomial NB", test_labels, nbPreds)


# ---------- YOUR CODE ----------

dic_str = []
for cat in category:
    name = cat.replace(' ','_') + ".out_term_list"
    file = open(name)
    res = ' '.join(file.readlines())
    dic_str.append(res)

from sklearn.feature_extraction.text import TfidfVectorizer

def get_dic_rel(abstract):
    temp = []
    for i in range(len(dic_str)):
        corpus = [dic_str[i],abstract]                                                                                                                                                                                                 
        vect = TfidfVectorizer(min_df=1, stop_words="english")                                                                                                                                                                                                   
        tfidf = vect.fit_transform(corpus)                                                                                                                                                                                                                       
        pairwise_similarity = tfidf * tfidf.T 
        temp.append(pairwise_similarity.toarray()[0][1])
    return temp

# # ------------- Linear SVC ---------------

from sklearn.svm import LinearSVC
from sklearn.multiclass import OneVsRestClassifier

svmClassifier = OneVsRestClassifier(LinearSVC(), n_jobs=-1)
svmClassifier.fit(vectorised_train_documents, train_labels)

svmPreds = svmClassifier.predict(vectorised_test_documents)

decision = svmClassifier.decision_function(vectorised_test_documents)

std_similarity = [preprocessing.scale(get_dic_rel(x)) for x in test_set['abstract'][:limiter]]



MyPred = []
alpha1 = 0.2
for i in range(len(decision)):
    zipped_lists = zip(decision[i],std_similarity[i])
    new_pred = [int(x + alpha1 * y>0) for (x, y) in zipped_lists]
    MyPred.append(new_pred)
    # decision[i] + alpha * std_similarity[i]


MyPred1 = []
# ignore the last 'nan'
for i in range(len(decision)):
    zipped_lists = zip(decision[i][:-1],std_similarity[i][:-1]) #exclude nan for modification
    new_pred = [int(x + alpha1 * y>=0) for (x, y) in zipped_lists]
    new_pred = new_pred + [int(decision[i][-1]>0)]
    MyPred1.append(new_pred)


# MyPred2 = []
# alpha2 = 0.5
# for i in range(len(decision)):
#     zipped_lists = zip(decision[i],std_similarity[i])
#     new_pred = [int(x + alpha2 * y>0) for (x, y) in zipped_lists]
#     MyPred2.append(new_pred)
#     # decision[i] + alpha * std_similarity[i]


# MyPred3 = []
# # ignore the last 'nan'
# for i in range(len(decision)):
#     zipped_lists = zip(decision[i][:-1],std_similarity[i][:-1]) #exclude nan for modification
#     new_pred = [int(x + alpha2 * y>=0) for (x, y) in zipped_lists]
#     new_pred = new_pred + [int(decision[i][-1]>0)]
#     MyPred3.append(new_pred)


# print("---pred and actual---")
# print(svmPreds)
# print(test_labels)
# print("---")
# print("--decision function---")
# print(svmClassifier.decision_function(vectorised_test_documents))
# print("---")
# print("---std similarity function---")
# print(std_similarity)



# print("---MyPred---")
# print(MyPred)
# print("---MyPred1 without modifying nan---")
# print(MyPred1)

# ---------- Further Processing ------------

# function for sorting 
def sortFunc(e):
    return e[0]

# for index in range(len(test_labels)):
#         print(svmPreds[index])
    
#         # calling your function to get the similarity vector
#         dictionary_similarities = get_dic_rel(test_set["title"][index])

 
#         dictionary_len = len(dictionary_similarities) - 1

#         print(dictionary_similarities)

#         # sort the values in the similarity vector to get position of the largest, second largest, etc
#         sorted_dictionary = []

#         for index1 in range(dictionary_len):
#             entry_with_index = [dictionary_similarities[index1], index1]
#             sorted_dictionary.append(entry_with_index)

#         sorted_dictionary.sort(key = sortFunc)


#         # svmPreds[index][sorted_dictionary[0][1]] = 0
#         # turn the bit of the largest to 1
#         svmPreds[index][sorted_dictionary[dictionary_len - 1][1]] = 1

#         print(test_labels[index])
#         print(svmPreds[index])
#         print("\n")




metricsReport("SVC Sq. Hinge Loss", test_labels, svmPreds)
print("+++++++alpha = 0.2++++++++++")
metricsReport("SVC Sq. Hinge Loss", test_labels, MyPred)
print("++++++alpha = 0.2+++++++++++")
metricsReport("SVC Sq. Hinge Loss", test_labels, MyPred1)
# print("+++++++alpha = 0.5++++++++++")
# metricsReport("SVC Sq. Hinge Loss", test_labels, MyPred2)
# print("+++++++alpha = 0.5++++++++++")
# metricsReport("SVC Sq. Hinge Loss", test_labels, MyPred3)

# ------------- Powerset svc ---------------

# from skmultilearn.problem_transform import LabelPowerset
# from sklearn.svm import LinearSVC
#
# powerSetSVC = LabelPowerset(LinearSVC())
# powerSetSVC.fit(vectorised_train_documents, train_labels)
#
# powerSetSVCPreds = powerSetSVC.predict(vectorised_test_documents)
# metricsReport("Power Set SVC", test_labels, powerSetSVCPreds)

# ------------- Binary Relevance ---------------

# from sklearn.svm import LinearSVC
# from skmultilearn.problem_transform import BinaryRelevance

# BinaryRelSVC = BinaryRelevance(LinearSVC())
# BinaryRelSVC.fit(vectorised_train_documents, train_labels)

# BinaryRelSVCPreds = BinaryRelSVC.predict(vectorised_test_documents)

# metricsReport("Binary Relevance", test_labels, BinaryRelSVCPreds)

# ------------- One-vs-Rest ---------------

# from sklearn.svm import LinearSVC
# from sklearn.multiclass import OneVsRestClassifier

# svmClassifier = OneVsRestClassifier(LinearSVC(), n_jobs=-1)
# svmClassifier.fit(vectorised_train_documents, train_labels)

# svmPreds = svmClassifier.predict(vectorised_test_documents)



# start_time = time.time()
# print(get_dic_rel(abstract_text_1))
# print("--- %s seconds ---" % (time.time() - start_time))

# # method 1, less complex, less functionality
# for entry in svmPreds:
#     dictionary_similarities = [0, 0, 0, 0, 0, 0, 0, 0, 0]
#     max_similarity = -2
#     max_index = -1
#     for index in range(len(dictionary_similarities)):
#         if dictionary_similarities[index] > max_similarity:
#             max_similarity = dictionary_similarities[index]
#             max_index = index
#     entry[index] = 1

# method 2



# for entry in svmPreds:
#     dictionary_similarities = [0, 0, 0, 0, 0, 0, 0, 0, 0]

#     dictionary_len = len(dictionary_similarities)

#     sorted_dictionary = []

#     for index in range(dictionary_len):
#         entry_with_index = [dictionary_similarities[index], index]
#         sorted_dictionary.append(entry_with_index)

#     sorted_dictionary.sort(key = sortFunc)

#     entry[sorted_dictionary[0][1]] = 1
#     entry[sorted_dictionary[dictionary_len - 1][1]] = 0



# for index in range(len(test_labels)):
#     pred_labels = []
#     correct = True
#     for index1 in range(len(test_labels[index])):
#         if svmPreds[index][index1] == 1:
#                     pred_labels.append(mlb.classes_[index1])

#         if test_labels[index][index1] != svmPreds[index][index1]:
#             correct = False
    
#     if correct == False:

#         dictionary_similarities = get_dic_rel(test_set["title"][index])
#         dictionary_len = len(dictionary_similarities)

#         sorted_dictionary = []

#         for index in range(dictionary_len):
#             entry_with_index = [dictionary_similarities[index], index]
#             sorted_dictionary.append(entry_with_index)

#         sorted_dictionary.sort(key = sortFunc)

#         svmPreds[index][sorted_dictionary[0][1]] = 1
#         svmPreds[index][sorted_dictionary[dictionary_len - 1][1]] = 0

        # print("Error at index " + str(index))
        # print(test_labels[index])
        # print(svmPreds[index])
        # print("Title:")
        # print(test_set["title"][index])
        # print("Actual labels:")
        # print(test_set["label"][index])
        # print("Predicted labels:")
        # print(pred_labels)
        # print("\n")



# f = open("test_label.txt", "w")

# for label in test_labels:
#     print(label)

# f.close()

# f = open("pred_label.txt", "w")

# for label in svmPreds:
#     print(label)

# f.close()


# metricsReport("One-vs-Rest", test_labels, svmPreds)



# for key, value in ModelsPerformance.items():
#     print("  " + key, " "*(20-len(key)) + "|", value)
#     print("-------------------------------------------")








'''
from sklearn.preprocessing import MultiLabelBinarizer
mlb = MultiLabelBinarizer()
new_Y_train = mlb.fit_transform(Y_train)

from sklearn.feature_extraction.text import CountVectorizer
cv = CountVectorizer()


# X_train = cv.fit_transform(X_train)

print(X_train.shape)
# print(mlb.inverse_transform(np.array([0 1 0 0 0 0 0 1 0])))




# X_test = [str(x) for x in test_set['title']]
Y_test = [str(x).split(';') for x in train_set['label']]

# X_test = cv.transform(X_test) # WE NEED A BETTER WAY TO CREATE FEATURES FOR INPUT!!!!



new_Y_test = mlb.transform(Y_test)
from sklearn.ensemble import RandomForestClassifier
print(X_test.shape)

clf = RandomForestClassifier(max_depth=5, random_state=0)

# from sklearn.svm import SVC
# clf = make_pipeline(StandardScaler(), SVC(gamma='auto'))
clf.fit(X_train, new_Y_train)
Y_pred = clf.predict(X_test)

from sklearn.metrics import accuracy_score

# print(Y_pred)
# print(Y_test)

print(Y_pred[:10])
print(new_Y_test[:10])
'''

# using title, remove words containing number
#   knn                  | 0.30417027595594603
# -------------------------------------------
#   Decision Tree        | 0.5989663093415009
# -------------------------------------------
#   Random Forest        | 0.6640521431727795
# -------------------------------------------
#   Bagging              | 0.6515487295779003
# -------------------------------------------
#   Boosting             | 0.5260246416897157
# -------------------------------------------
#   Multinomial NB       | 0.5946821919452614
# -------------------------------------------
#   SVC Sq. Hinge Loss   | 0.7289738532342084
# -------------------------------------------
#   Power Set SVC        | 0.7365989798864402
# -------------------------------------------
#   Binary Relevance     | 0.7290107222334614
# -------------------------------------------
#   One-vs-Rest          | 0.7289738532342084
# -------------------------------------------

# using title, keep words containing number
#   knn                  | 0.6338198872319123
# -------------------------------------------
#   Decision Tree        | 0.5978654469220507
# -------------------------------------------
#   Random Forest        | 0.6480126111924333
# -------------------------------------------

# using title, keep words containing number, remove high frequency words
#   knn                  | 0.5825
# -------------------------------------------
#   Decision Tree        | 0.5941422594142259
# -------------------------------------------
#   Random Forest        | 0.6410212765957447
# -------------------------------------------


# using abstract, remove words containing number
#   Power Set SVC        | 0.7928107364727084
# -------------------------------------------
#   Binary Relevance     | 0.7947216890595009
# -------------------------------------------
#   knn                  | 0.2394598155467721
# -------------------------------------------
#   Decision Tree        | 0.605324397281951
# -------------------------------------------
#   Random Forest        | 0.6457146213945838
# -------------------------------------------

# using abstract, remove words containing number, remove high frequency words
#   Binary Relevance     | 0.7929397093385774
# -------------------------------------------
#   One-vs-Rest          | 0.7929397093385774
# -------------------------------------------
#   Power Set SVC        | 0.7912556904400607
# -------------------------------------------
#   SVC Sq. Hinge Loss   | 0.7929397093385774
# -------------------------------------------

# ------knn Model Metrics-----
# Accuracy: 0.2197
# Hamming Loss: 0.1871
# Precision:
#   - Macro: 0.7623
#   - Micro: 0.2957
# Recall:
#   - Macro: 0.1609
#   - Micro: 0.2012
# F1-measure:
#   - Macro: 0.1509
#   - Micro: 0.2395
# ------Decision Tree Model Metrics-----
# Accuracy: 0.4756
# Hamming Loss: 0.1142
# Precision:
#   - Macro: 0.5134
#   - Micro: 0.6124
# Recall:
#   - Macro: 0.4944
#   - Micro: 0.6004
# F1-measure:
#   - Macro: 0.5034
#   - Micro: 0.6063
# ------Random Forest Model Metrics-----
# Accuracy: 0.4515
# Hamming Loss: 0.0823
# Precision:
#   - Macro: 0.8252
#   - Micro: 0.8816
# Recall:
#   - Macro: 0.3003
#   - Micro: 0.5057
# F1-measure:
#   - Macro: 0.3801
#   - Micro: 0.6427
# ------Bagging Model Metrics-----
# Accuracy: 0.4961
# Hamming Loss: 0.0779
# Precision:
#   - Macro: 0.7646
#   - Micro: 0.7953
# Recall:
#   - Macro: 0.5271
#   - Micro: 0.6304
# F1-measure:
#   - Macro: 0.6149
#   - Micro: 0.7033
# ------Boosting Model Metrics-----
# Accuracy: 0.5192
# Hamming Loss: 0.0716
# Precision:
#   - Macro: 0.7590
#   - Micro: 0.8439
# Recall:
#   - Macro: 0.5395
#   - Micro: 0.6267
# F1-measure:
#   - Macro: 0.6270
#   - Micro: 0.7192
# ------Multinomial NB Model Metrics-----
# Accuracy: 0.4554
# Hamming Loss: 0.0858
# Precision:
#   - Macro: 0.5792
#   - Micro: 0.8298
# Recall:
#   - Macro: 0.2978
#   - Micro: 0.5208
# F1-measure:
#   - Macro: 0.3585
#   - Micro: 0.6400
# ------SVC Sq. Hinge Loss Model Metrics-----
# Accuracy: 0.6439
# Hamming Loss: 0.0578
# Precision:
#   - Macro: 0.8217
#   - Micro: 0.8281
# Recall:
#   - Macro: 0.6596
#   - Micro: 0.7639
# F1-measure:
#   - Macro: 0.7146
#   - Micro: 0.7947
# ------Power Set SVC Model Metrics-----
# Accuracy: 0.6939
# Hamming Loss: 0.0590
# Precision:
#   - Macro: 0.7918
#   - Micro: 0.8158
# Recall:
#   - Macro: 0.6658
#   - Micro: 0.7711
# F1-measure:
#   - Macro: 0.7120
#   - Micro: 0.7928
# ------Binary Relevance Model Metrics-----
# Accuracy: 0.6439
# Hamming Loss: 0.0578
# Precision:
#   - Macro: 0.8217
#   - Micro: 0.8281
# Recall:
#   - Macro: 0.6596
#   - Micro: 0.7639
# F1-measure:
#   - Macro: 0.7146
#   - Micro: 0.7947
# ------One-vs-Rest Model Metrics-----
# Accuracy: 0.6439
# Hamming Loss: 0.0578
# Precision:
#   - Macro: 0.8217
#   - Micro: 0.8281
# Recall:
#   - Macro: 0.6596
#   - Micro: 0.7639
# F1-measure:
#   - Macro: 0.7146
#   - Micro: 0.7947
#   Binary Relevance     | 0.7947216890595009
# -------------------------------------------
#   One-vs-Rest          | 0.7947216890595009
# -------------------------------------------
#   Multinomial NB       | 0.6399909317615053
# -------------------------------------------
#   SVC Sq. Hinge Loss   | 0.7947216890595009
# -------------------------------------------
#   Power Set SVC        | 0.7928107364727084
# -------------------------------------------
#   Bagging              | 0.7032729518320296
# -------------------------------------------
#   Boosting             | 0.7192165166754897
# -------------------------------------------
#   Decision Tree        | 0.6063259887268831
# -------------------------------------------
#   Random Forest        | 0.6427482706061671
# -------------------------------------------
#   knn                  | 0.2394598155467721
# -------------------------------------------
